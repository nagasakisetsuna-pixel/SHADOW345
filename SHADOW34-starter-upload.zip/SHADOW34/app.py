import os
import sqlite3
from pathlib import Path
from flask import Flask, jsonify, render_template, request, session

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("SHADOW34_DB_PATH", BASE_DIR / "shadow34.db"))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get(
    "SHADOW34_SECRET_KEY", "dev-only-change-this-before-deployment"
)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                creator TEXT NOT NULL,
                description TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

init_db()

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response

@app.get("/")
def home():
    return render_template("index.html", age_confirmed=session.get("age_confirmed", False))

@app.post("/age-confirm")
def age_confirm():
    data = request.get_json(silent=True) or {}
    if data.get("adult") is not True:
        return jsonify(error="Age confirmation is required."), 400
    session["age_confirmed"] = True
    return jsonify(ok=True)

@app.get("/api/health")
def health():
    return jsonify(status="ok", service="SHADOW34")

@app.get("/api/submissions")
def submissions():
    if not session.get("age_confirmed"):
        return jsonify(error="Confirm that you are an adult first."), 403
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, title, creator, description, status, created_at "
            "FROM submissions WHERE status = 'approved' ORDER BY id DESC"
        ).fetchall()
    return jsonify(items=[dict(row) for row in rows])

@app.post("/api/submissions")
def create_submission():
    if not session.get("age_confirmed"):
        return jsonify(error="Confirm that you are an adult first."), 403
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()[:100]
    creator = str(data.get("creator", "")).strip()[:80]
    description = str(data.get("description", "")).strip()[:1000]
    if not title or not creator:
        return jsonify(error="Title and creator are required."), 400
    with get_db() as conn:
        cur = conn.execute(
            "INSERT INTO submissions (title, creator, description) VALUES (?, ?, ?)",
            (title, creator, description),
        )
        submission_id = cur.lastrowid
    return jsonify(
        id=submission_id,
        status="pending",
        message="Submitted for moderator review."
    ), 201

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
