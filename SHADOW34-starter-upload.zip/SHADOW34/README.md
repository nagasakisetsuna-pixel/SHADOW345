# SHADOW34

A dark-themed Flask starter for an artwork discovery community.

## Included
- Responsive dark/red landing page.
- Self-attested 18+ entry screen (not legal age verification).
- Health endpoint at `/api/health`.
- Creator metadata submissions stored as pending for review.
- Public API returns only approved submission records.

## Run locally
Requires Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000.

## Deployment notes
- Set `SHADOW34_SECRET_KEY` to a long random secret before deployment.
- Set `SHADOW34_DB_PATH` to a persistent writable disk path. Ephemeral filesystems can lose SQLite data.
- Use HTTPS.
- Confirm the host's acceptable-use policy in writing before deploying adult-oriented content. This repository contains no explicit images.
- A checkbox/self-attestation is not robust or legally sufficient age assurance. Obtain jurisdiction-specific legal guidance and implement appropriate age assurance before restricted content is accessible.
- Do not enable public uploads until file validation, malware scanning, storage isolation, rate limits, rights/consent checks, moderation tooling, and takedown procedures are implemented.

## Not production complete
This is an initial web starter, not the full SHADOW34 platform. It does not include account authentication, image uploads, favorites, administrator login, a moderation dashboard, or a production database. SQLite is suitable only for development or a host with persistent storage. Do not advertise it as a finished public adult-content service.

## Safety and rights
Only publish lawful content with documented rights and consent. Never host sexual content involving minors, non-consensual intimate imagery, or material that violates applicable law or hosting terms.
